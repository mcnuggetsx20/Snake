#include <iostream>
#include <fstream>

using namespace std;

int main(){
}  